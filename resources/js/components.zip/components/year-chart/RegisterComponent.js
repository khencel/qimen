Vue.component(
    'year-chart',
    ()=>import("../year-chart/index.vue")
);
