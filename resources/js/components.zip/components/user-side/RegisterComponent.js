Vue.component(
    'victory-day',
    ()=>import("../user-side/VictoryDay.vue")
);


Vue.component(
    'victory-day-guest',
    ()=>import("../user-side/GuestVicDay.vue")
);
