Vue.component(
    'user-search',
    ()=>import("../search/SearchComponent.vue")
);

Vue.component(
    'show-search',
    ()=>import("../search/ShowComponent.vue")
);
