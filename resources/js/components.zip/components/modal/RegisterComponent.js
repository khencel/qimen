Vue.component(
    'create-year-chart-modal',
    ()=>import('../modal/CreateYear.vue')
);



