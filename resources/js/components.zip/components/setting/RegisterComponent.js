Vue.component(
    'user-profile',
    ()=>import("../setting/Profile.vue")
);

Vue.component(
    'user-change-password',
    ()=>import("../setting/ChangePassword.vue")
);