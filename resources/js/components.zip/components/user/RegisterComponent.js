Vue.component(
    'user-list',
    ()=>import("../user/UserList.vue")
);

Vue.component(
    'user-registration',
    ()=>import("../user/Registration.vue")
);