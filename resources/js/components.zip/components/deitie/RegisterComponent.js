Vue.component(
    'single-attributes',
    ()=>import("../deitie/SingleAttributesDoor")
);

Vue.component(
    'multiple-attributes',
    ()=>import("../deitie/MultipleAttributes")
);


